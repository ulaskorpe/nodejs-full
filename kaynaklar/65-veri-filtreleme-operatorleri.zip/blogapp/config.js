const config = {
    db: {
        host: "localhost",
        user: "root",
        password: "sadik123",
        database: "blogdb"
    }
}

module.exports = config;